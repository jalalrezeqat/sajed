<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('admin.about')); ?>"><button  class="btnaboutadd btn btn-dark">رجوع</button> </a>
<div class="formaddm">
    <form action="<?php echo e(url('admin/about/update/'.$about->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
          <label for="inputtitelmistion">عنوان المهمة</label>
          <input type="text" class="form-control" name='our_mission_titel' value="<?php echo e($about->our_mission_titel); ?>" id="our_mission_titel" placeholder="عنوان المهة">
        </div>
        <div class="form-group">
          <label for="inputtitelmistion">نص المهمة</label>
          <input type="text" class="form-control" name='our_mission_text' value="<?php echo e($about->our_mission_text); ?>" id="our_mission_text" placeholder="نص المهمة">
        </div>
        
        <button type="submit" class="btn btn-info">تعديل</button>
      </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sajed/alpha/resources/views/admin/layouts/about/edit.blade.php ENDPATH**/ ?>