<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('admin.about')); ?>"><button  class="btnaboutadd btn btn-dark">رجوع</button> </a>
<div class="formaddm">
    <form action="<?php echo e(url('admin/about/updatevistion/'.$about->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
          <label for="inputtitelmistion">رؤيتنا</label>

          <textarea name="our_vision" class="form-control editvistion" id="our_vision" ><?php echo e($about->our_vision); ?></textarea>

        </div>
       
        
        <button type="submit" class="btn btn-info">تعديل</button>
      </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sajed/alpha/resources/views/admin/layouts/about/editvistion.blade.php ENDPATH**/ ?>