    <?php $__env->startSection('content'); ?>
    
    <div id="carouselExampleSlidesOnly" class="carousel slider  slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block  w-100" src="img/slide1.png" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src=".../800x400?auto=yes&bg=666&fg=444&text=Second slide" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src=".../800x400?auto=yes&bg=555&fg=333&text=Third slide" alt="Third slide">
        </div>
      </div>
    </div>
    
    <div class="m">
     
    </div>
    

<div class="contener ">
  <div class="m-1">
      <h3 class="text-center ">الدورات الاكثر طلبا </h3>
      <h5 class="text-center  ">اختر دورات التوجيهي التي تناسبك وتساعدك على زيادة معدلك</h5>
    </div>
    
    <div class=" card-box-home  card-w   slider">
      <div class="row row-cols-1  card-w dir ovarflow  row-cols-md-3 ">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col  ">
          <div class="card-home card ">
            <img src="img/img_avatar.png" class="card-img-top-home" alt="...">
            <div class="card-body">
              <h5 class="card-title-home "><?php echo e($courses->name); ?></h5>
              <p class="card-text-home"><?php echo e($courses->summary); ?></p>
              <button class="card-button"> قراءة المزيد ></button>
              <button class="but-card"><?php echo e($courses->price); ?>₪   </button>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
    <div class="card-btn-allcourse ">
    <a  href="<?php echo e(url('/courses')); ?> " class="btn-lg btn-allcourse">جميع الدورات</a>
    </div>
  </div>
</div>
</div>
    
    
    <div class="m-1">
      <h3 class="text-center ">معلمي منصة الفا </h3>
      <h5 class="text-center ">نفتخر في ألفا بتواجد  أفضل المُدرسين على مستوى الوطن!</h5>
    </div>

    
    <div id="carouselExampleIndicators" class="carousel slider  slide" data-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block  w-100" src="img/slide2.png" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="img/slide2.png" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block  w-100" src="img/slide2.png" alt="Third slide">
        </div>
      </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    
    

    <div class=" m-3  card-text-home">
     <h2 class="card-text-home">الاسئلة الشائعة</h2>
     <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
   <p>

     <button class="btn  qustion" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($question->id); ?>" aria-expanded="false" aria-controls="collapseExample"></button>
     <button type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($question->id); ?>" aria-expanded="false" aria-controls="collapseExample" class="btn qustion-text ">  <?php echo e($question->question); ?> </button>
   </p>
   <div class="collapse" id="collapse<?php echo e($question->id); ?>">
     <div class=" qustion-box card-body">
       <?php echo e($question->question_text); ?>

     </div>
   </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sajed/alpha/resources/views/welcome.blade.php ENDPATH**/ ?>