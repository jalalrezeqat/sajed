<?php $__env->startSection('content'); ?>
<div>


  <a href="<?php echo e(route('admin.about.add')); ?>"><button  class="btnaboutadd btn btn-dark">اضافة الى مهمتنا</button> </a>
</div>
<div class=" table-responsive">
    <table class=" table-admin-connectus  ">
        <thead class="thead-green-connectus">
          <tr class="">
            <th scope="col ">رؤيتنا</th>
            <th scope="col"></th>
           
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class=""> <?php echo e($vision->our_vision); ?> </td>
            <td class="editdelete"> <a href="<?php echo e(route('admin.about.editvistion',$vision->id)); ?>"  class="btn btn-success editdelete">تعديل</a>
                  
            </td>
          
          </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <table class=" table-admin-connectus  ">
        <thead class="thead-green-connectus">
          <tr class="">
            <th scope="col ">مهمتنا</th>
            <th scope="col"></th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="tdnamecontectus"><?php echo e($mission->our_mission_titel); ?> </td>
            <td class=""><?php echo e($mission->our_mission_text); ?> </td>

            <td class="editdelete">  <a href="<?php echo e(route('admin.about.edit',$mission->id)); ?>"  class="btn btn-success editdelete">تعديل</a>
                  <a href="<?php echo e(route('admin.about.destroy',$mission->id)); ?>" onclick="return confirm(' هل انت متاكد سيتم الحدف') " class="btn btn-danger editdelete">حذف</a>
            </td>
          
          </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      </div>

   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sajed/alpha/resources/views/admin/layouts/about/about.blade.php ENDPATH**/ ?>